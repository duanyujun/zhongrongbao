//
//  BIDCategoryListViewController.h
//  zhongrongbao
//
//  Created by mal on 15/6/25.
//  Copyright (c) 2015年 cnsoft. All rights reserved.
//

#import "BIDBaseViewController.h"

@interface BIDCategoryListViewController : BIDBaseViewController
{
    IBOutlet UITableView *_tableView;
}

@end
