//
//  BIDAttributeCell.h
//  zhongrongbao
//
//  Created by mal on 15/7/17.
//  Copyright (c) 2015年 cnsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDAttributeCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *contentLabel;

@end
