//
//  BIDAttributeCell.m
//  zhongrongbao
//
//  Created by mal on 15/7/17.
//  Copyright (c) 2015年 cnsoft. All rights reserved.
//

#import "BIDAttributeCell.h"

@implementation BIDAttributeCell
@synthesize contentLabel;

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
