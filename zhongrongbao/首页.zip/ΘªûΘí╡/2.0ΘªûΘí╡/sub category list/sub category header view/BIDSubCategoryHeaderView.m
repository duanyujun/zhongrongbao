//
//  BIDSubCategoryHeaderView.m
//  zhongrongbao
//
//  Created by mal on 15/6/30.
//  Copyright (c) 2015年 cnsoft. All rights reserved.
//

#import "BIDSubCategoryHeaderView.h"

@implementation BIDSubCategoryHeaderView
@synthesize headTitleLabel;
@synthesize subTitleLabel;
@synthesize categoryImgView;

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
