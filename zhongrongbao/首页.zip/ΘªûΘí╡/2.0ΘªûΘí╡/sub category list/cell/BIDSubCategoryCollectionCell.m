//
//  BIDSubCategoryCollectionCell.m
//  zhongrongbao
//
//  Created by mal on 15/6/30.
//  Copyright (c) 2015年 cnsoft. All rights reserved.
//

#import "BIDSubCategoryCollectionCell.h"

@implementation BIDSubCategoryCollectionCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {}
    return self;
}

- (void)awakeFromNib {
    // Initialization code
}

@end
