//
//  BIDCreditRightTransferView.h
//  zhongrongbao
//
//  Created by mal on 14-10-15.
//  Copyright (c) 2014年 cnsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDCreditRightTransferView : UITableViewController
/**
 *债权转让id
 */
@property (copy, nonatomic) NSString *creditRightTransferId;

@end
