//
//  BIDEnterpriseInfoCell.h
//  zhongrongbao
//
//  Created by mal on 14-9-11.
//  Copyright (c) 2014年 cnsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDEnterpriseInfoCell : UITableViewCell

@end
