//
//  BIDTextCell.h
//  zhongrongbao
//
//  Created by mal on 14-10-14.
//  Copyright (c) 2014年 cnsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDTextCell : UITableViewCell

@property (strong, nonatomic)IBOutlet UILabel *contentLabel;
@property (strong, nonatomic)IBOutlet UILabel *lineLable;

@end
