//
//  BIDExpandCell.h
//  zhongrongbao
//
//  Created by mal on 14-10-13.
//  Copyright (c) 2014年 cnsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDExpandCell : UITableViewCell

@end
